#ifndef _HALMAC_TX_DESC_IE_NIC_H_
#define _HALMAC_TX_DESC_IE_NIC_H_
#endif
