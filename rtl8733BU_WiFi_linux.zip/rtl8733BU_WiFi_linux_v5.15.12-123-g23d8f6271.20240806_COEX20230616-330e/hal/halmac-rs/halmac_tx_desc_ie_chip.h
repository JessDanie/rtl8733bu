#ifndef _HALMAC_TX_DESC_IE_CHIP_H_
#define _HALMAC_TX_DESC_IE_CHIP_H_
#endif
