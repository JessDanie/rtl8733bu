#ifndef _HALMAC_TX_DESC_IE_AP_H_
#define _HALMAC_TX_DESC_IE_AP_H_
#endif
